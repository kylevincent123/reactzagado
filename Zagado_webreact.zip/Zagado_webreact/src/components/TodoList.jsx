import React, { useState, useEffect } from "react";
import styles from "../modules/todoList.module.css";
import dropdownIcon from '../assets/dropdown.png'; 

import Todo from "./Todo";

export default function TodoList() {
  const [todos, setTodos] = useState([]);
  const [user_id, setUser_id] = useState("");
  const [openGroups, setOpenGroups] = useState({});

  useEffect(() => {
    const token = localStorage.getItem("token");
    setUser_id(token);
    const apiUrl = `https://todoapi-1-av65.onrender.com/${token}/todos`;
    fetch(apiUrl)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to fetch todos");
        }
        return response.json();
      })
      .then((data) => setTodos(data))
      .catch((error) => {
        console.error("Error fetching todos:", error);
      });
  }, []);

  // Function to group todos by date
  const groupTodosByDate = () => {
    const groupedTodos = {};

    todos.forEach((todo) => {
      const date = new Date(todo.date).toLocaleDateString();
      if (!groupedTodos[date]) {
        groupedTodos[date] = [];
      }
      groupedTodos[date].push(todo);
    });

    return groupedTodos;
  };

  // Sort grouped todos by date from latest to oldest
  const sortedDates = Object.keys(groupTodosByDate()).sort((a, b) => {
    return new Date(b) - new Date(a);
  });

  const groupedTodos = groupTodosByDate();

  // Function to toggle the todo list visibility and icon change
  const toggleTodoList = (date) => {
    setOpenGroups({
      ...openGroups,
      [date]: !openGroups[date],
    });
  };

  // Function to handle todo update
  const handleTodoUpdate = () => {
    // Refresh todos after update
    const apiUrl = `https://todoapi-1-av65.onrender.com/${user_id}/todos`;
    fetch(apiUrl)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Failed to fetch updated todos");
        }
        return response.json();
      })
      .then((data) => setTodos(data))
      .catch((error) => {
        console.error("Error fetching updated todos:", error);
      });
  };

  return (
    <div className={styles.listContainer}>
      <h3>Journals</h3>
      {sortedDates.map((date) => (
        <div className={styles.dateGroupContainer} key={date}>
          <div
            className={`${styles.dateGroup} ${
              openGroups[date] ? styles.open : ""
            }`}
          >
            <div
              className={styles.dateGroupHeader}
              onClick={() => toggleTodoList(date)}
            >
              <div className={styles.date}>{date}</div>
              <div className={styles.dropdownBtnContainer}>
                <button className={styles.dropdownBtn}>
                  <img
                    src={dropdownIcon} // Use the imported image
                    alt="dropdown"
                  />
                </button>
              </div>
            </div>

            <hr className={styles.divider} />
            <ul className={openGroups[date] ? styles.open : ""}>
              {groupedTodos[date].map((todo) => (
                <li key={todo.id}>
                  <Todo
                    todo={todo}
                    user_id={user_id}
                    onTodoUpdate={handleTodoUpdate}
                  />
                </li>
              ))}
            </ul>
          </div>
        </div>
      ))}
    </div>
  );
}
