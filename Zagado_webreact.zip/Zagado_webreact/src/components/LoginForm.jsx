import React, { useState } from "react";
import styles from "../modules/loginForm.module.css";
import eyeOnIcon from "../assets/Eye on.png";
import eyeOffIcon from "../assets/Eye off.png";
import { Link } from "react-router-dom";
import ForgotPassModal from "./ForgotPassModal";

export default function LoginForm() {
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(null);
  const [forgotPassModalIsOpen, setForgotPassModalIsOpen] = useState(false);
  const [forgotAcc, setForgotAcc] = useState({ username: "", email: "" });
 

  

  const openForgotPassModal = () => {
    setForgotPassModalIsOpen(true);
  };

  const closeForgotPassModal = () => {
    setForgotPassModalIsOpen(false);
    setUsername("");
    setPassword("");
    setError(null);
  };

  const handleChange = (field, value) => {
    setForgotAcc({
      ...forgotAcc,
      [field]: value,
    });
  };

  const handleForgotPass = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const apiUrl = `https://todoapi-1-av65.onrender.com/forgotPassword`;
      const requestBody = {
        username: forgotAcc.username,
        email: forgotAcc.email,
      };

      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        const errorMessage = await response.text(); // Get the error message as text
        throw new Error(errorMessage); // Throw an error with the extracted message
      }

      // Proceed with success handling
      alert("An email has been sent to your email address");
      console.log("Successfully sent an email.");
      setLoading(false);
    } catch (error) {
      console.error("Error sending email:", error);
      setError(error.message || "Failed to send email. Please try again.");
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (!username || !password) {
        setError("Both username and password are required!");
        setLoading(false);
        return;
      }

      const apiUrl = "https://todoapi-1-av65.onrender.com/login"; // Replace with your API endpoint
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userName: username,
          password: password,
        }),
      });

      
      if (response.status === 401) {
        throw new Error("Invalid username or password!! Please try again.");
      }
      const data = await response.json(); // Parse response body as JSON

      if (!response.ok) {
        throw new Error(data.message || "Login failed");
      }

      setLoading(false);
      setError(null);

      localStorage.setItem("token", data.user_id);
      window.location.href = "/dashboard";
      console.log("User logged in successfully");
    } catch (error) {
      console.error("Error logging in:", error.message);
      setError(error.message || "Login failed. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div>
      <form className={styles.formContainer} onSubmit={handleSubmit}>
        <h1 className={styles.formTitle}>Journee Login</h1>
        {error && <p className={styles.error}>{error}</p>}
        <div className={styles.inputContainer}>
          <label className={styles.inputLabel}>Username</label>
          <input
            className={styles.modernInput}
            type="text"
            value={username}
            placeholder="Enter username..."
            onChange={(e) => setUsername(e.target.value)}
          />
        </div>
        <div className={styles.inputContainer}>
          <label className={styles.inputLabel}>Password</label>
          <div className={styles.passwordInput}>
            <input
              className={styles.modernInput}
               type="password"
              value={password}
              placeholder="Enter password..."
              onChange={(e) => setPassword(e.target.value)}
            />
           
          </div>
        </div>
        <p className={styles.hyperlink}>
         <Link to="/signup">Sign up instead</Link>
        </p>
        
        <button
          className={styles.modernButton}
          type="submit"
          disabled={loading}
        >
          {loading ? "Logging in..." : "LOGIN"}
        </button>
       
      </form>
      {/* FORGOT PASSWORD MODAL */}
      <ForgotPassModal
        isOpen={forgotPassModalIsOpen}
        closeModal={closeForgotPassModal}
        handleForgotPass={handleForgotPass}
        handleChange={handleChange}
        loading={loading}
        error={error}
        forgotAcc={forgotAcc}
      />
    </div>
  );
}
