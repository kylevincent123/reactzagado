export default function SubmitButton({ title, handleSubmit, loading }) {
  return (
    <button
      style={{
        backgroundColor: "#f21818",
        color: "white",
        padding: "10px 20px",
        margin: "10px",
        border: "none",
        borderRadius: "4px",
        cursor: "pointer",
        fontSize: "12px",
        fontWeight: "bold",
        boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.2)",
      }}
      onClick={handleSubmit}
    >
      {loading ? "Please wait..." : title}
    </button>
  );
}
