import React, { useState } from "react";
import styles from "../modules/forgotPassModal.module.css";
import Modal from "react-modal";
import SubmitButton from "./SubmitButton";
import ResetPassModal from "./ResetPassModal";

export default function ForgotPassModal({
  isOpen,
  closeModal,
  loading,
  forgotAcc,
  handleChange,
  handleForgotPass,
  error,
}) {
  //VARIABLES
  const [resetPassModalIsOpen, setResetPassModalIsOpen] = useState(false);
  const [resetToken, setResetToken] = useState("");
  const [resetPassword, setResetPassword] = useState("");
  const [errorReset, setErrorReset] = useState(null);
  //FUNCTIONS
  const openResetPassModal = () => {
    setResetPassModalIsOpen(true);
  };

  const closeResetPassModal = () => {
    setResetPassModalIsOpen(false);
    setResetToken("");
    setResetPassword("");
    setErrorReset(null);
  };
  const handleResetPass = async (e) => {
    e.preventDefault();
    setErrorReset(null);

    // Validation (you can add more validation as needed)
    if (!resetToken || !resetPassword) {
      setErrorReset("Please enter token and new password.");
      return;
    }
    try {
      const apiUrl = `https://todoapi-1-av65.onrender.com/resetPassword?token=${encodeURIComponent(
        resetToken
      )}`;

      const resetPasswordRequest = {
        password: resetPassword,
      };
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(resetPasswordRequest),
      });

      if (!response.ok) {
        const errorResponse = await response.text();
        throw new Error(errorResponse);
      }

      alert("Password changed successfully!");
      console.log("Password changed successfully!");
      closeModal();
      closeResetPassModal();
    } catch (error) {
      console.error("Error resetting password:", error);
      setErrorReset(error.message);
    }
  };

  //RETURN
  return (
    <Modal
      className={styles.containerModal}
      overlayClassName={styles.overlay}
      isOpen={isOpen}
      onRequestClose={closeModal}
      contentLabel="Forgot Pass Modal"
      shouldCloseOnOverlayClick={true}
      ariaHideApp={false}
      shouldCloseOnEsc={true}
    >
      <h2>FORGOT PASSWORD</h2>
      {error && <p className={styles.error}>{error}</p>}
      <form onSubmit={handleForgotPass}>
        <div className={styles.inputContainer}>
          <label className={styles.inputLabel}>Username: </label>
          <input
            className={styles.modernInput}
            type="text"
            value={forgotAcc.username}
            onChange={(e) => handleChange("username", e.target.value)}
            placeholder="Enter username..."
          />
        </div>
        <div className={styles.inputContainer}>
          <label className={styles.inputLabel}>Email: </label>
          <input
            className={styles.modernInput}
            type="text"
            value={forgotAcc.email}
            onChange={(e) => handleChange("email", e.target.value)}
            placeholder="Enter email address..."
          />
        </div>
        <div className={styles.btnContainer}>
          <SubmitButton
            type="button"
            title="SEND EMAIL"
            loading={loading}
            onClick={handleForgotPass}
          />
          <SubmitButton
            type="button"
            title="CANCEL"
            handleSubmit={closeModal}
          />
        </div>
      </form>
      {/* RESET PASSWORD MODAL */}
      <ResetPassModal
        isOpen={resetPassModalIsOpen}
        closeModal={closeResetPassModal}
        handleResetPass={handleResetPass}
        loading={loading}
        resetToken={resetToken}
        setResetToken={setResetToken}
        resetPassword={resetPassword}
        setResetPassword={setResetPassword}
        errorReset={errorReset}
      />
      <SubmitButton
        type="button"
        title="RESET PASSWORD"
        handleSubmit={openResetPassModal}
      />
    </Modal>
  );
}
