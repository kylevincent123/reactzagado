import React from "react";
import Modal from "react-modal";
import styles from "../modules/customModal.module.css";
import SubmitButton from "./SubmitButton";

export default function CustomModal({
  isOpen,
  closeModal,
  currentTodo,
  handleUpdate,
  handleChange,
  loading,
}) {
  return (
    <Modal
      className={styles.containerModal}
      overlayClassName={styles.overlay}
      isOpen={isOpen}
      onRequestClose={closeModal}
      contentLabel="Edit Todo Modal"
      shouldCloseOnOverlayClick={true} 
      shouldCloseOnEsc={true} 
    >
      <h2>missed something? </h2>
      <form onSubmit={handleUpdate}>
        <div className={styles.inputContainer}>
          <label className={styles.inputLabel}>Title: </label>
          <input
            className={styles.modernInput}
            type="text"
            value={currentTodo.todoTitle}
            onChange={(e) => handleChange("todoTitle", e.target.value)}
          />
        </div>
        <div className={styles.inputContainer}>
          <label className={styles.inputLabel}>Story: </label>
          <textarea
            value={currentTodo.desc}
            onChange={(e) => handleChange("desc", e.target.value)}
            className={styles.modernTextarea}
            placeholder="Enter description..."
            rows={5}
          />
        </div>
        <div className={styles.btnContainer}>
          <SubmitButton title="SAVE" loading={loading} />
          <SubmitButton title="CANCEL" handleSubmit={closeModal} />
        </div>
      </form>
    </Modal>
  );
}
