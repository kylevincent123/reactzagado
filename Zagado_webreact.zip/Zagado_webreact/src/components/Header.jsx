import styles from "../modules/header.module.css";
import { Link } from "react-router-dom";
import logoutIcon from "../assets/Log out.png";
export default function Header() {
  const handleLogout = () => {
    localStorage.removeItem("token");

    window.location.href = "/";
  };
  //RETURN
  return (
    <div className={styles.headerContainer}>
      <Link to="/dashboard" className={styles.logoLink}>
        <h1>Welcome!</h1>
      </Link>
      <Link to="/createTodo" className={styles.inlineLink}>
        Create Journal
      </Link>
      <div className={styles.logoutContainer}>
        <button onClick={handleLogout} className={styles.logoutButton}>
          <img src={logoutIcon} alt="Logout" className={styles.logoutIcon} />
          Logout
        </button>
      </div>
    </div>
  );
}
