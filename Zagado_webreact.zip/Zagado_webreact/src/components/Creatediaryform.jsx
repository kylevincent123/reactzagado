import React, { useState } from "react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css"; 
import styles from "../modules/creatediaryform.module.css"; 
import SubmitButton from "./SubmitButton";

const TodoForm = () => {
  const [loading, setLoading] = useState(false);
  const [todoTitle, setTodoTitle] = useState("");
  const [desc, setDesc] = useState("");
  const [date, setDate] = useState(null); 

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    if (!todoTitle || !desc || !date) {
      alert("Please fill in all fields.");
      setLoading(false);
      return;
    }

    const userId = localStorage.getItem("token"); 
    const apiUrl = `https://todoapi-1-av65.onrender.com/${userId}/addTodo`;

    const newTodo = {
      todoTitle,
      desc,
      date: date.toISOString(),
    };

    try {
      await addTodo(apiUrl, newTodo);
      alert("Todo added successfully!");
      window.location.href = "/dashboard";
      resetForm();
    } catch (error) {
      console.error("Error adding todo:", error.message);
      alert("Error adding todo. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const addTodo = async (url, todo) => {
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(todo),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || "Failed to add todo.");
    }
    return response.json();
  };

  const resetForm = () => {
    setTodoTitle("");
    setDesc("");
    setDate(null);
  };

  const handleCancel = () => {
    window.location.href = "/dashboard";
  };

  return (
    <form className={styles.formContainer} onSubmit={handleSubmit}>
      <h1 className={styles.formTitle}>Create Journal</h1>
      <div className={styles.inputContainer}>
        <label className={styles.inputLabel}>Title</label>
        <input
          className={styles.modernInput}
          type="text"
          value={todoTitle}
          placeholder="Tell your story..."
          onChange={(e) => setTodoTitle(e.target.value)}
        />
      </div>
      <div className={styles.inputContainer}>
        <label className={styles.inputLabel}>Story</label>
        <textarea
          className={styles.modernTextarea}
          value={desc}
          placeholder="Whatever comes in your mind..."
          rows={5}
          onChange={(e) => setDesc(e.target.value)}
        />
      </div>
      <div className={styles.inputDate}>
        <label className={styles.inputLabel}>Date</label>
        <DatePicker
          selected={date}
          onChange={(date) => setDate(date)}
          dateFormat="MMMM dd, yyyy"
          className={styles.modernDate}
          placeholderText="Select date..."
        />
      </div>
      <SubmitButton title="MAKE DIARY" loading={loading} />
      <button
        type="button" 
        onClick={handleCancel} 
        className={styles.cancelButton}
      >
        CANCEL
      </button>
    </form>
  );
};

export default TodoForm;
