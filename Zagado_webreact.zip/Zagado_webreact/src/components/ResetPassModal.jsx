import React from "react";
import styles from "../modules/resetPassModal.module.css";
import Modal from "react-modal";
import SubmitButton from "./SubmitButton";

const ResetPassModal = ({
  isOpen,
  closeModal,
  handleResetPass,
  resetToken,
  setResetToken,
  resetPassword,
  setResetPassword,
  errorReset,
}) => {
  return (
    <Modal
      className={styles.containerModal}
      overlayClassName={styles.overlay}
      isOpen={isOpen}
      onRequestClose={closeModal}
      contentLabel="Reset Pass Modal"
      shouldCloseOnOverlayClick={true}
      ariaHideApp={false}
      shouldCloseOnEsc={true}
    >
      <h2>RESET PASSWORD</h2>
      {errorReset && <p className={styles.error}>{errorReset}</p>}
      <form onSubmit={handleResetPass}>
        <div className={styles.inputContainer}>
          <label className={styles.inputLabel}>Token: </label>
          <input
            className={styles.modernInput}
            type="text"
            value={resetToken}
            onChange={(e) => setResetToken(e.target.value)}
            placeholder="Enter token..."
            required
          />
        </div>
        <div className={styles.inputContainer}>
          <label className={styles.inputLabel}>New Password: </label>
          <input
            className={styles.modernInput}
            type="password"
            value={resetPassword}
            onChange={(e) => setResetPassword(e.target.value)}
            placeholder="Enter new password..."
            required
          />
        </div>
        <div className={styles.btnContainer}>
          <SubmitButton type="button" title="SAVE" />
          <SubmitButton
            type="button"
            title="CANCEL"
            handleSubmit={closeModal}
          />
        </div>
      </form>
    </Modal>
  );
};

export default ResetPassModal;
