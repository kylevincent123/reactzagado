import React from "react";
import styles from "../modules/customDeleteModal.module.css";
import SubmitButton from "./SubmitButton";
import Modal from "react-modal";

const CustomDeleteModal = ({ isOpen, closeModal, handleDelete, loading }) => {
  return (
    <Modal
      className={styles.containerModal}
      overlayClassName={styles.overlay}
      isOpen={isOpen}
      onRequestClose={closeModal}
      contentLabel="Delete Todo Modal"
      shouldCloseOnOverlayClick
      shouldCloseOnEsc
      aria={{
        labelledby: "delete-modal-title",
        describedby: "delete-modal-description",
      }}
    >
      <h2 id="delete-modal-title">Confirm Deletion</h2>
      <p id="delete-modal-description">
        Are you sure you want to delete this diary? This action cannot be undone.
      </p>
      <div className={styles.btnContainer}>
        <SubmitButton
          title={loading ? "Deleting..." : "DELETE"}
          loading={loading}
          onClick={handleDelete}
          className={styles.deleteButton}
        />
        <SubmitButton
          title="CANCEL"
          onClick={closeModal}
          className={styles.cancelButton}
        />
      </div>
    </Modal>
  );
};

export default CustomDeleteModal;
