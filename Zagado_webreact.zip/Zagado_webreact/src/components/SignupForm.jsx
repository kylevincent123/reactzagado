import React, { useState } from "react";


import styles from "../modules/signupForm.module.css";
import SubmitButton from "./SubmitButton";

export default function SignupForm() {
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [error, setError] = useState(null);


  //FUCNTIONS
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      if (!name.trim() || !password.trim() || !email.trim()) {
        throw new Error("All fields are required!");
      }

      const apiUrl = "https://todoapi-1-av65.onrender.com/signup";
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userName: name,
          password: password,
          email: email,
        }),
      });

      let data;
      if (response.headers.get("Content-Type")?.includes("application/json")) {
        data = await response.json();
      } else {
        data = await response.text();
        throw new Error(data || "Signup failed");
      }

      if (!response.ok) {
        throw new Error(data.message || "Signup failed");
      }

      setLoading(false);
      setError(null);
      alert("Signup successful!");
      window.location.href = "/";

      console.log("Signup successful");

      setName("");
      setPassword("");
      setEmail("");
    } catch (error) {
      console.error("Error signing up:", error.message);
      setError(error.message || "Sign up failed. Please try again.");

      setLoading(false);
    }
  };

  return (
    <form className={styles.formContainer} onSubmit={handleSubmit}>
      <h1 className={styles.formTitle}>Sign Up</h1>
      <h5 className={styles.formTitle}>Every adventure begins with a single step!</h5>
      {error && <p className={styles.error}>{error}</p>}
      <div className={styles.inputContainer}>
        <label className={styles.inputLabel}>Name</label>
        <input
          className={styles.modernInput}
          type="text"
          value={name}
          placeholder="Enter username..."
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      <div className={styles.inputContainer}>
        <label className={styles.inputLabel}>Password</label>
        <div className={styles.passwordInput}>
          <input
            className={styles.modernInput}
             type="password"
            value={password}
            placeholder="Enter password..."
            onChange={(e) => setPassword(e.target.value)}
          />
         
        </div>
      </div>
      <div className={styles.inputContainer}>
        <label className={styles.inputLabel}>Email</label>
        <input
          className={styles.modernInput}
          type="email"
          value={email}
          placeholder="Enter email..."
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>
      <p className={styles.hyperlink}>
       <a href="/">Login</a>
      </p>
      <SubmitButton title="SIGN UP" loading={loading} />
    </form>
  );
}
