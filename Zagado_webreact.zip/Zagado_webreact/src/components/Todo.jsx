import React, { useState } from "react";
import CustomModal from "./CustomModal";
import styles from "../modules/todo.module.css";
import CustomDeleteModal from "./CustomDeleteModal";

export default function Todo({ todo, user_id, onTodoUpdate }) {
  const [loading, setLoading] = useState(false);
  const [editModalIsOpen, setEditModalIsOpen] = useState(false);
  const [deleteModalIsOpen, setDeleteModalIsOpen] = useState(false);
  const [currentTodo, setCurrentTodo] = useState({
    id: todo.id,
    todoTitle: todo.todoTitle,
    desc: todo.desc,
  });

  const openEditModal = () => {
    setEditModalIsOpen(true);
  };

  const closeEditModal = () => {
    setEditModalIsOpen(false);
  };

  const openDeleteModal = () => {
    setDeleteModalIsOpen(true);
  };

  const closeDeleteModal = () => {
    setDeleteModalIsOpen(false);
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const apiUrl = `https://todoapi-1-av65.onrender.com/updateTodo/${user_id}/${currentTodo.id}`;
      const requestBody = {
        todoTitle: currentTodo.todoTitle,
        desc: currentTodo.desc,
      };

      const response = await fetch(apiUrl, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        throw new Error("Failed to update todo.");
      }

      alert("Todo updated successfully!");
      console.log("Todo updated successfully.");
      setLoading(false);
      closeEditModal();

      if (onTodoUpdate) {
        onTodoUpdate();
      }
    } catch (error) {
      console.error("Error updating todo:", error);
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    setLoading(true);
    try {
      const apiUrl = `https://todoapi-1-av65.onrender.com/deleteTodo/${user_id}/${currentTodo.id}`;

      const response = await fetch(apiUrl, {
        method: "DELETE",
      });

      if (!response.ok) {
        throw new Error("Failed to delete todo.");
      }
      alert("Todo deleted successfully!");
      console.log("Todo deleted successfully.");
      setLoading(false);

      if (onTodoUpdate) {
        onTodoUpdate();
      }

      closeDeleteModal();
    } catch (error) {
      console.error("Error deleting todo:", error);
      setLoading(false);
    }
  };

  const handleChange = (field, value) => {
    setCurrentTodo({
      ...currentTodo,
      [field]: value,
    });
  };

  return (
    <div className={styles.todoItem}>
      <div className={styles.headerContainer}>
        <div className={styles.titleContainer}>
          <strong>{todo.todoTitle.toUpperCase()}</strong>
        </div>

        <div className={styles.btnContainer}>
          <button className={styles.editBtn} onClick={openEditModal}>
            📝
          </button>
          <button className={styles.delBtn} onClick={openDeleteModal}>
            ❌
          </button>
        </div>
      </div>
      <hr />
      <p className={styles.todoDesc}>📜{todo.desc}</p>

      <CustomModal
        isOpen={editModalIsOpen}
        closeModal={closeEditModal}
        handleUpdate={handleUpdate}
        handleChange={handleChange}
        currentTodo={currentTodo}
        loading={loading}
      />

      <CustomDeleteModal
        isOpen={deleteModalIsOpen}
        closeModal={closeDeleteModal}
        handleDelete={handleDelete}
        loading={loading}
      />
    </div>
  );
}
