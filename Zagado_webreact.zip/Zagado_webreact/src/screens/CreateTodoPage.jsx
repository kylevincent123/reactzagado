import CreateTodoForm from "../components/Creatediaryform";
import Header from "../components/Header";
import styles from "../modules/createTodoPage.module.css";
export default function CreateTodoPage() {
  return (
    <div className={styles.createContainer}>
      <Header />
      <div className={styles.content}>
        <CreateTodoForm />
      </div>
    </div>
  );
}
