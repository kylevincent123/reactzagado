import Header from "../components/Header";
import TodoList from "../components/TodoList";
import styles from "../modules/dashBoardPage.module.css";

export default function DashBoardPage() {
  //VARIABLES

  //RETURN
  return (
    <div className={styles.dashboard}>
      <Header />
      <div className={styles.content}>
        <TodoList />
      </div>
    </div>
  );
}
