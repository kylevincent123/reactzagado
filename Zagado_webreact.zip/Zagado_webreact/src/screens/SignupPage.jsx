import SignupForm from "../components/SignupForm";
import styles from "../modules/signupForm.module.css";
export default function SignupPage() {
  return (
    <div>
      <SignupForm />
    </div>
  );
}
