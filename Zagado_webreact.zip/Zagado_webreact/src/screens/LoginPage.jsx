import LoginForm from "../components/LoginForm";
import styles from "../modules/loginPage.module.css";
import React from "react";

export default function LoginPage() {
  return <LoginForm />;
}
