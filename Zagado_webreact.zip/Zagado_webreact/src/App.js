import "./App.css";
import { Routes, Route } from "react-router-dom";
import LoginPage from "./screens/LoginPage";
import SignupPage from "./screens/SignupPage";
import DashBoardPage from "./screens/DashBoardPage";
import CreateTodoPage from "./screens/CreateTodoPage";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LoginPage />} />
      <Route path="/signup" element={<SignupPage />} />
      <Route path="/dashboard" element={<DashBoardPage />} />
      <Route path="/createTodo" element={<CreateTodoPage />} />
    </Routes>
  );
}
